package com.cts.ipm.axway.custom.filter.jsondecrypt;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;
import com.vordel.config.Circuit;
import com.vordel.config.ConfigContext;
import com.vordel.circuit.CircuitAbortException;
import com.vordel.circuit.Message;
import com.vordel.circuit.MessageProcessor;
import com.vordel.circuit.MessageProperties;
import com.vordel.common.base64.Base64Util;
import com.vordel.dwe.ContentSource;
import com.vordel.es.EntityStoreException;
import com.vordel.mime.Body;
import com.vordel.mime.ContentType;
import com.vordel.mime.HeaderSet;
import com.vordel.mime.RawBody;
import com.vordel.trace.Trace;

/**
 * This Processor acts as a simple Addition Web Service. It extracts two
 * parameters from a SOAP message and adds them together. The result is then
 * returned to the client. The incoming message is expected in the following
 * format:
 * 
 * <?xml version="1.0" encoding="utf-8"?>
 * <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 * <soap:Body> <Add xmlns="http://startvbdotnet.com/web/"> <a>1</a>
 * <b>1</b> </Add> </soap:Body> </soap:Envelope>
 * 
 * The SimpleFilter contains the local name of the two parameters (a and b), and
 * contains the namespace that these elements belong to
 * (http://startvbdotnet.com/web/).
 */
public class JSONDecryptProcessor extends MessageProcessor {

	/**
	 * This method attaches the Filter to the Processor object. This is called
	 * at startup and on every refresh. This should contain server-side
	 * config/initialization. For example, if this filter is required to
	 * establish connections to any 3rd party products/servers, the connection
	 * setup should be done here.
	 * 
	 * @param ctx
	 *            Configuration context for the filter.
	 * @param entity
	 *            The Entity object
	 */
	public void filterAttached(ConfigContext ctx, com.vordel.es.Entity entity) throws EntityStoreException {
		// nothing to do here for initialisation
		super.filterAttached(ctx, entity);
	}

	/**
	 * The invoke method performs the filter processing.
	 * 
	 * @param c
	 *            The policy circuit
	 * @param message
	 *            The message
	 * @return true or false.
	 */
	public boolean invoke(Circuit c, Message message) throws CircuitAbortException {

		try {
			JSONDecryptFilter f = (JSONDecryptFilter) getFilter();
			Trace.debug("DEBUG: Input Parameters : " + f.certLoc + f.certPass + f.certAlias);
			String certFileLoc = f.certLoc;
			byte[] bytePassword = Base64Util.decode(f.certPass);
			String strPassword = new String(bytePassword);
			String strAlias = f.certAlias;
			Trace.debug("DEBUG: certFileLoc : " + certFileLoc);
			Trace.debug("DEBUG: content.body : " + message.get("content.body"));
			
			RawBody body = (RawBody) message.get("content.body");
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			body.write(baos, 0);
			String content = new java.lang.String(baos.toByteArray(), "utf-8");
			Trace.debug("DEBUG: content.body.string : " + content);
			
			// Trace.debug("DEBUG: XMLBody: " + XMLBody.getDocument(message));

			//Object doc = message.get("json.decrypt");
			//Trace.debug("DEBUG: doc : " + doc);
			String pCipherText = content; //doc.toString();
			Trace.debug("DEBUG: pDataString : " + pCipherText);
	        char[] chPassword = new char[strPassword.length()];
	        Trace.debug("DEBUG: strPassword : " + strPassword);
	        strPassword.getChars(0, strPassword.length(), chPassword, 0);
	        KeyStore keyStore = KeyStore.getInstance("JKS");
	        FileInputStream fis = new FileInputStream(certFileLoc);
	        keyStore.load(fis, chPassword);
	        fis.close();
	        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	        cipher.init(2, keyStore.getKey(strAlias, chPassword));
	        byte[] ciphertextBytes = Base64Util.decode(pCipherText);
	        byte[] decryptedText = cipher.doFinal(ciphertextBytes);
	        String result = new String(decryptedText);
	        
			Trace.debug("DEBUG: result : " + result);
			// Set the response by setting the content body
			// to be the response
			Trace.debug("DEBUG: Sets headers....");
			HeaderSet responseHeaders = new HeaderSet();
			responseHeaders.addHeader("Content-Type", "text/plain");
			Trace.debug("DEBUG: HTTP Body Content ....");
			StringBuffer response = new StringBuffer("RESPONSE_START");
			response.append(result);
			response.append("RESPONSE_END");
			responseHeaders.addHeader("Result", result);
			/*Trace.debug("DEBUG: HTTP Body ContentSource ....");
			 */
			Trace.debug("DEBUG: HTTP Body ....");
			ContentSource cs = null;
			Body convertedBody = Body.create(responseHeaders, new ContentType(null, "text/xml"), cs);
			Trace.debug("DEBUG: Puts HTTP Body into message ....");
			message.put(MessageProperties.CONTENT_BODY, convertedBody);
			//message.put(MessageProperties.HTTP_HEADERS, responseHeaders);
			
			//message.put(MessageProperties.HTTP_BODY, response);
			Trace.debug("DEBUG: Returns true");
			return true;
		} catch (Exception exp) {
			Trace.error("IOException in SimpleProcessor: " + exp.getMessage());
			return false;
		}
	}
	private static PublicKey getPublicKeyFromCert(String pCertificate) {
        PublicKey pub = null;
        try {
            FileInputStream inStream = new FileInputStream(pCertificate);
            Trace.debug("DEBUG: inStream : " + inStream);
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate)cf.generateCertificate(inStream);
            inStream.close();
            pub = cert.getPublicKey();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Trace.debug("DEBUG: pub : " + pub);
        return pub;
    }
}