package com.cts.ipm.axway.custom.filter.jsonencrypt;

import java.io.FileInputStream;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;
import com.fasterxml.jackson.databind.JsonNode;
import com.vordel.config.Circuit;
import com.vordel.config.ConfigContext;
import com.vordel.circuit.CircuitAbortException;
import com.vordel.circuit.Message;
import com.vordel.circuit.MessageProcessor;
import com.vordel.circuit.MessageProperties;
import com.vordel.common.base64.Base64Util;
import com.vordel.dwe.ContentSource;
import com.vordel.es.EntityStoreException;
import com.vordel.mime.Body;
import com.vordel.mime.ContentType;
import com.vordel.mime.HeaderSet;
import com.vordel.mime.JSONBody;
import com.vordel.trace.Trace;

/**
 * This Processor acts as a simple Addition Web Service. It extracts two
 * parameters from a SOAP message and adds them together. The result is then
 * returned to the client. The incoming message is expected in the following
 * format:
 * 
 * <?xml version="1.0" encoding="utf-8"?>
 * <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 * <soap:Body> <Add xmlns="http://startvbdotnet.com/web/"> <a>1</a>
 * <b>1</b> </Add> </soap:Body> </soap:Envelope>
 * 
 * The SimpleFilter contains the local name of the two parameters (a and b), and
 * contains the namespace that these elements belong to
 * (http://startvbdotnet.com/web/).
 */
public class JSONEncryptProcessor extends MessageProcessor {

	/**
	 * This method attaches the Filter to the Processor object. This is called
	 * at startup and on every refresh. This should contain server-side
	 * config/initialization. For example, if this filter is required to
	 * establish connections to any 3rd party products/servers, the connection
	 * setup should be done here.
	 * 
	 * @param ctx
	 *            Configuration context for the filter.
	 * @param entity
	 *            The Entity object
	 */
	public void filterAttached(ConfigContext ctx, com.vordel.es.Entity entity) throws EntityStoreException {
		// nothing to do here for initialisation
		super.filterAttached(ctx, entity);
	}

	/**
	 * The invoke method performs the filter processing.
	 * 
	 * @param c
	 *            The policy circuit
	 * @param message
	 *            The message
	 * @return true or false.
	 */
	public boolean invoke(Circuit c, Message message) throws CircuitAbortException {

		try {
			JSONEncryptFilter f = (JSONEncryptFilter) getFilter();
			String certFileLoc = f.cerLoc;
			Trace.debug("DEBUG: certFileLoc : " + certFileLoc);
			JsonNode doc = JSONBody.getJSON(message);
			Trace.debug("DEBUG: doc : " + doc);
			String pDataString = doc.toString();
			Trace.debug("DEBUG: pDataString : " + pDataString);
	        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	        Trace.debug("DEBUG: cipher : " + cipher);
			cipher.init(1, getPublicKeyFromCert(certFileLoc));
			byte[] plaintextBytes = pDataString.getBytes();
	        byte[] cipherText = cipher.doFinal(plaintextBytes);
	        
	        String result = Base64Util.encodeBytes(cipherText);
			Trace.debug("DEBUG: result : " + result);
			// Set the response by setting the content body
			// to be the response
			Trace.debug("DEBUG: Sets headers....");
			HeaderSet responseHeaders = new HeaderSet();
			responseHeaders.addHeader("Content-Type", "text/plain");
			Trace.debug("DEBUG: HTTP Body Content ....");
			StringBuffer response = new StringBuffer("RESPONSE_START");
			response.append(result);
			response.append("RESPONSE_END");
			responseHeaders.addHeader("Result", result);
			/*Trace.debug("DEBUG: HTTP Body ContentSource ....");
			 */
			Trace.debug("DEBUG: HTTP Body ....");
			ContentSource cs = null;
			Body convertedBody = Body.create(responseHeaders, new ContentType(null, "text/xml"), cs);
			Trace.debug("DEBUG: Puts HTTP Body into message ....");
			message.put(MessageProperties.CONTENT_BODY, convertedBody);
			//message.put(MessageProperties.HTTP_HEADERS, responseHeaders);
			
			//message.put(MessageProperties.HTTP_BODY, response);
			Trace.debug("DEBUG: Returns true");
			return true;
		} catch (Exception exp) {
			Trace.error("IOException in SimpleProcessor: " + exp.getMessage());
			return false;
		}
	}
	private static PublicKey getPublicKeyFromCert(String pCertificate) {
        PublicKey pub = null;
        try {
            FileInputStream inStream = new FileInputStream(pCertificate);
            Trace.debug("DEBUG: inStream : " + inStream);
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate)cf.generateCertificate(inStream);
            inStream.close();
            pub = cert.getPublicKey();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Trace.debug("DEBUG: pub : " + pub);
        return pub;
    }
}