package com.cts.ipm.axway.custom.filter.jsonencrypt;

import com.vordel.circuit.DefaultFilter;
import com.vordel.config.ConfigContext;
//import com.vordel.circuit.FilterConfigureContext;
import com.vordel.common.util.PropDef;
import com.vordel.circuit.MessageProperties;
import com.vordel.es.EntityStoreException;

/**
 * SimpleFilter contains the local name of the two parameters (a and b) and
 * contains the namespace that these elements belong to
 * (http://startvbdotnet.com/web/)
 **/

public class JSONEncryptFilter extends DefaultFilter {

	// element name of the certificate file location
	String cerLoc;

	/**
	 * Set the message attributes used by this filter
	 */
	protected final void setDefaultProperties() {
		reqProps.add(new PropDef(MessageProperties.CONTENT_BODY, com.vordel.mime.Body.class));
	}

	/**
	 * This method is called to set the config fields for the filter
	 * 
	 * @param ctx
	 *            The configuration context for this filter
	 * @param entity
	 *            The entity object
	 */
	public void configure(ConfigContext ctx, com.vordel.es.Entity entity) throws EntityStoreException {
		super.configure(ctx, entity);

		// read the settings for the processor
		cerLoc = entity.getStringValue("cerLoc");
	}

	/**
	 * Returns the server runtime Processor class associated with this Filter
	 * class.
	 */
	public Class getMessageProcessorClass() {
		return JSONEncryptProcessor.class;
	}

	/**
	 * Returns the GUI component for this Filter
	 */
	public Class getConfigPanelClass() throws ClassNotFoundException {
		// Avoid any compile or runtime dependencies on SWT and other UI
		// libraries by lazily loading the class when required.
		return Class.forName("com.cts.ipm.axway.custom.filter.jsonencrypt.JSONEncryptFilterUI");
	}
}