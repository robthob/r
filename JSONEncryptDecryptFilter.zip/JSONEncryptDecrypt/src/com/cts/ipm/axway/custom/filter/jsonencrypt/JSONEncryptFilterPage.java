package com.cts.ipm.axway.custom.filter.jsonencrypt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;

import com.vordel.client.manager.wizard.VordelPage;

public class JSONEncryptFilterPage extends VordelPage 
{    
    /** 
     * Create the configuration page. Set the title and description 
     * here. The title and description are maintained in the 
     * resources.properties file for customization and 
     * internationalization purposes.
     */
    public JSONEncryptFilterPage() {
        // Call the super constructor with a unique name for this 
        // page to bind it with its corresponding wizard.
        super("jsonEncryptPage");
        setTitle(_("JSON_ENCRYPT_PAGE"));
        setDescription(_("JSON_ENCRYPT_PAGE_DESCRIPTION"));
        setPageComplete(false);
    }
    
    /**
     * Get the unique identifier for the help page for this filter. 
     * The ID-to-HTML page mapping is maintained in the following file:
     * <policy_studio_build>/plugins/
     * com.vordel.client.rcp.common.resources_version/contexts.xml. 
     */
    public String getHelpID() {
        return "jsonEncrypt.help";
    }

    /**
     * Any post-processing of the configuration values can happen 
     * here, before they are persisted to the Entity Store. If the 
     * configuration is not complete and valid, notify the user here  
     * with a dialog box and return false, otherwise return true.
     * 
     * @see com.vordel.client.manager.util.MsgBox
     */
    public boolean performFinish() {
        // Simple mutually independent values here, no checking required, 
        // so return true
        return true;
    }

    /**
     * Create the main control for the Filter configuration dialog. 
     * This will include the text fields for setting the particular 
     * Field Values in the Entity.
     */
    public void createControl(Composite parent) {
        // Create a Panel with two columns        
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;    
        Composite container = new Composite(parent, SWT.NULL);
        container.setLayout(layout);
        
        // Add controls to populate the appropriate Entity Fields
        // You use the localization keys for the field names and 
        // descriptions which will map to entries in the 
        // resources.properties file.        
        createLabel(container, "JSON_ENCRYPT_NAME");
        createTextAttribute(container, "name", "JSON_ENCRYPT_NAME_DESC");

        createLabel(container, "JSON_ENCRYPT_CERTLOC");
        createTextAttribute(container, "cerLoc", "JSON_ENCRYPT_CERTLOC_DESC");        
        
        // Finish up the page definition
        setControl(container);
        setPageComplete(true);        
    }
}