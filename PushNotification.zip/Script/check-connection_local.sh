#!/bin/bash

#PROXY=$1
#while [[ -z "$PROXY" ]]; do
#  echo -n Enter proxy socket address hostname:port or ip_address:port \>\
#  read PROXY
#done

#echo "Proxy Server : $PROXY"

function check-google {
  echo "Checking Google FCM ....."
  curl \
    --verbose \
    --http1.0 \
    -1 \
    --header "Authorization: key=AIzaSyAef1-DThoxJbAevvNi47y1O3SbqRfbljE" \
    --header "Content-Type: application/json" \
    --header "Cache-Control: no-cache" \
    --data '{"collapse_key":"a_collapse_key","delay_while_idle":true,"priority":1,"restricted_package_name":"com.scmobile.android","data":{"Foo":"Bar","Marco":"Polo","Hello":"World!"},"time_to_live":100,"notification":{"title":"Notification","text":"Hello Me!","color":"#ff0000"},"dry_run":false,"registration_ids":["ehtYICrribs:APA91bEsnS2WFngp3xGaLPF8xODjBGp5SZebNSzFDGL3u3VfN7UuqlN0yktgHzIJgvnH5CcgKLZpA1xPDhG8k9cDGI2aEMH5I8ZZUF-QhnMixjaCaZ-3J4n1RczJju1yKMDRyk0qX27T"]}'  \
    "https://fcm.googleapis.com/fcm/send"
  RET_CODE=$?
  echo ""
  [[ $RET_CODE -ne 0 ]] && echo "Connection to Google FCM : FAILED"
  [[ $RET_CODE -eq 0 ]] && echo "Connection to Google FCM : FAILED"
}

function check-apple {
  echo "Checking Apple APNS ...."
  curl \
    --verbose \
    -3 \
    --proxy 10.65.1.33:8080 \
    --cert ./pushcert.pem \
    --header "Content-Type: aplication/json" \
    --header "apns-topic:even.start" \
    --data '{"aps":{"alert":{"body":"Hello World!",},"sound":"","content-available":1})' \
    "https://gateway.sandbox.push.apple.com:2195/3/E6D11A9A43D8025E504E6C90FDB35DAF0FB2711D6B37A25565010ABCF459C30C"
  RET_CODE=$?
  [[ $RET_CODE -ne 0 ]] && echo "Connection to Apple APNS : FAILED"
  [[ $RET_CODE -eq 0 ]] && echo "Connection to Apple APNS : SUCCESS"
}

check-google
# check-apple
