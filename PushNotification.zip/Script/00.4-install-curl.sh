# Install cURL with HTTP/2 support
brew install curl --with-nghttp2
brew link curl --force
