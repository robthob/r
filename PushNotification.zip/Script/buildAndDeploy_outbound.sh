#!/bin/bash
#Deployment Script
AXWAYCREDENTIAL="--username=1531656 --password=1531656"
echo "Preparing Deployment Package for :" ${ENV_NAME}_${DEPLOYINFO}
echo "Federated XML files will be read from:" ${FED_FILE_LOCATION}/${DEPLOYINFO}

ACTUALGROUPNAME=${ENV_NAME}_${DEPLOYINFO}
export ACTUALGROUPNAME
GENERATED_FED_FILE_LOCATION=${FED_FILE_LOCATION}/generated/${DEPLOYINFO}/${ACTUALGROUPNAME}_${VERSION}.fed
export GENERATED_FED_FILE_LOCATION
echo "Generated FED file will be stored into :" $GENERATED_FED_FILE_LOCATION

if [ -f $FED_FILE_LOCATION/$DEPLOYINFO/configs.xml ] ; then 
	sed -i -e 's/DEV_/'$ENV_NAME'_/g' $FED_FILE_LOCATION/$DEPLOYINFO/configs.xml 
else 
	echo "no file exists:"  $FED_FILE_LOCATION/$DEPLOYINFO/configs.xml ; 
	exit;
fi

#Change config file Env xml files to point correct XXX_CertStore.xml XXX_UserStore.xml XXX_EnvSettingsStore.xml

cd $PWD
sh run.sh buildAndDeploy.py $AXWAYCREDENTIAL --environment=$ENV_NAME --deployInfo=$DEPLOYINFO --federatedFolder=$FED_FILE_LOCATION --name="$SERVICE_NAME" --description="$SERVICE_DESC"  --versionComment="$VERSION_COMMENT" --version=$VERSION

#Revert the config file Env xml files to point back to DEV_CertStore.xml DEV_UserStore.xml DEV_EnvSettingsStore.xml
cd $FED_FILE_LOCATION/$DEPLOYINFO
sed -i -e 's/'$ENV_NAME'_/DEV_/g' $FED_FILE_LOCATION/$DEPLOYINFO/configs.xml

chmod 755 $GENERATED_FED_FILE_LOCATION

echo "Build done :" $GENERATED_FED_FILE_LOCATION

#Deployment for only DEV environment
if [ "$ENV_NAME" = "DEV" ]; then
        echo "Deployment Start.."
        /apps/axway/axway-7.3.1/apigateway/posix/bin/managedomain $AXWAYCREDENTIAL --deploy --group $ACTUALGROUPNAME --archive_filename $GENERATED_FED_FILE_LOCATION
        echo "Deployment Completed"
fi

