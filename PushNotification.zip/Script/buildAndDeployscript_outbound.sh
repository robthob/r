#!/bin/bash
#Deployment Script
#$1 Version
#$2 Environment (DEV, SIT , UAT etc)
echo "Starting Build...."
cd /apps/axway/axway-7.3.1/apigateway/axway_scripts/scripts

ENV_NAME=DEV


DEPLOYINFO=CHANNELS_OUTBOUND_API_GRP
FED_FILE_LOCATION=/tmp/Deployment; 
SERVICE_NAME="Outbound Services"
SERVICE_DESC="Outbound Services"
VERSION_COMMENT="Outbound Services"
VERSION=$1;

if [ -n "$2" ]; then
    ENV_NAME=$2
else
    echo "No ENV Passed, default to DEV"
	ENV_NAME=DEV
fi

export ENV_NAME
export VERSION
export DEPLOYINFO
export FED_FILE_LOCATION
export SERVICE_NAME SERVICE_DESC VERSION_COMMENT
cd $PWD
./buildAndDeployscript.sh
