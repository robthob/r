#!/bin/bash

openssl=/usr/local/opt/openssl/bin/openssl

authKey="./apns.p8"
authKeyId=WXA9JC93AH
teamId=2BC28V6R7M
bundleId=even.start
endpoint=https://api.development.push.apple.com


# --------------------------------------------------------------------------

base64() {
   $openssl base64 -e -A | tr -- '+/' '-_' | tr -d =
}

sign() {
   printf "$1"| $openssl dgst -binary -sha256 -sign "$authKey" | base64
}

time=$(date +%s)
header=$(printf '{ "alg": "ES256", "kid": "%s" }' "$authKeyId" | base64)
claims=$(printf '{ "iss": "%s", "iat": %d }' "$teamId" "$time" | base64)
jwt="$header.$claims.$(sign $header.$claims)"

echo $jwt
