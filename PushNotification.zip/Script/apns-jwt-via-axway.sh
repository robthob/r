#!/bin/bash

# --------------------------------------------------------------------------

deviceToken1=E6D11A9A43D8025E504E6C90FDB35DAF0FB2711D6B37A25565010ABCF459C30C


#bundleId=com.sc.Breeze.testing
bundleId=even.start
endpoint=http://192.168.56.102:8080/apple/api/push


payloadTemplate=$(cat ./apns-alert-template.json)

jwt=$(./jwt_local.sh)

deviceTokens=($deviceToken1)

sendOtp() {

    deviceToken=$1
    otp=$2
    payload=$(printf "$payloadTemplate" "$otp")
    echo $payload
    echo "INFO Sending to OTP($otp) to device ($deviceToken)"
    curl \
       --verbose \
       --insecure \
       --header "content-type: application/json" \
       --header "authorization: bearer $jwt" \
       --header "apns-topic: $bundleId" \
       --data "$payload" \
       $endpoint/3/device/$deviceToken
}

for deviceToken in ${deviceTokens[@]}; do
    otp=$(date +%s)
    sendOtp $deviceToken $otp
    sleep 1
done
