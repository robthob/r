public class JabberFilterPage extends VordelPage 
{    
    public JabberFilterPage() {
        super("jabberPage");
        setTitle(("JABBER_PAGE"));
        setDescription(("JABBER_PAGE_DESCRIPTION"));
        setPageComplete(false);
    }
    
    public String getHelpID() {
        return "jabber.help";
    }

    public boolean performFinish() {
        return true;
    }

    public void createControl(Composite parent) {
        Composite panel = 
          render(parent, 
          getClass().getResourceAsStream("send_instant_message.xml"));
        setControl(panel);
        setPageComplete(true);
    } 
}