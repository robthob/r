import com.vordel.circuit.Circuit;
import com.vordel.circuit.CircuitAbortException;
import com.vordel.circuit.ConfigContext;
import com.vordel.circuit.Message;
import com.vordel.circuit.MessageListener;
import com.vordel.circuit.MessageProcessor;
import com.vordel.client.policy.gui.GenerationException;
import com.vordel.el.Selector;
import com.vordel.es.EntityStoreException;
import com.vordel.precipitate.SolutionPack;
import com.vordel.trace.Trace;
import com.vordel.client.manager.wizard.VordelPage;


public class JabberProcessor extends MessageProcessor {

    private Selector<String> to;
	private Selector<String> password;
	private Selector<String> resourceName;
	private Selector<String> from;
	private Selector<String> messageStr;

	public void filterAttached(SolutionPack ctx, com.vordel.es.Entity entity) 
      throws EntityStoreException {
        super.filterAttached(ctx, entity);
        to = new Selector<String>(entity.getStringValue("toEmailAddress"), 
          String.class);
        byte[] passwordBytes = entity.getEncryptedValue("password");
        if (passwordBytes != null) {
            try {
                passwordBytes = ctx.getCipher().decrypt(passwordBytes);
            } catch (GenerationException exp) {
	         Trace.error(exp);
	     }
        }
        String pass = new String(passwordBytes);
        password = new Selector<String>(pass, String.class);
        resourceName = new Selector<String>(entity.getStringValue("resourceName"), 
          String.class);
        from = new Selector<String>(entity.getStringValue("fromEmailAddress"), 
          String.class);
        messageStr = new Selector<String>(entity.getStringValue("messageStr"), 
          String.class);
    }

    public boolean invoke(Circuit c, Message message)
      throws CircuitAbortException {
    	XMPPConnection connection = null;
       try {
           ConnectionConfiguration config =
           new ConnectionConfiguration("talk.google.com", 5222, "gmail.com");
           connection = new XMPPConnection(config);
    	    SASLAuthentication.supportSASLMechanism("PLAIN", 0);
           connection.connect();
           connection.login(from.substitute(message), password.substitute(message),
             resourceName.substitute(message));
    	} catch (org.jivesoftware.smack.XMPPException ex) {
    	    Trace.error("Error establishing connection to XMPP Server");
    	}
       Chat chat = connection.getChatManager().createChat(to.substitute(message), 
         new MessageListener(){
           @Override
           public void processMessage(Chat arg0, 
             org.jivesoftware.smack.packet.Message arg1) {
               Trace.debug(arg1.getBody());
           }
       });
       try {
           chat.sendMessage(messageStr.substitute(message));
           connection.disconnect();
       } catch (org.jivesoftware.smack.XMPPException ex) {
           Trace.error("Error Delivering block");
       }
       return true;
    }
}