import com.vordel.circuit.ConfigContext;
import com.vordel.circuit.DefaultFilter;
import com.vordel.circuit.MessageProperties;
import com.vordel.circuit.PropDef;
import com.vordel.es.EntityStoreException;
import com.vordel.precipitate.SolutionPack;

public class JabberFilter extends DefaultFilter {

    protected final void setDefaultPropertyDefs() {
    	 reqProps.add(new PropDef(MessageProperties.CONTENT_BODY, 
          com.vordel.mime.Body.class));
    }

    public void configure(SolutionPack ctx, com.vordel.es.Entity entity)
      throws EntityStoreException {
        super.configure(ctx, entity);
    }

    public Class getMessageProcessorClass() {
        return JabberProcessor.class;
    }

    public Class getConfigPanelClass() throws ClassNotFoundException {
        // Avoid any compile or runtime dependencies on SWT and other UI
        // libraries by lazily loading the class when required.
        return Class.forName("com.vordel.jabber.filter.JabberFilterUI");
    }
}