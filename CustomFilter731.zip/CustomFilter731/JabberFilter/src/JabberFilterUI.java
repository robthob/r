public class JabberFilterUI extends DefaultGUIFilter 
{
    public Vector<VordelPage> getPropertyPages() {
        Vector<VordelPage> pages = new Vector<VordelPage>();       
        pages.add(new JabberFilterPage());       
        pages.add(createLogPage());        
        return pages;
    }
    
    public String[] getCategories() {
        return new String[]{_("FILTER_GROUP_JABBER")};
    }
    
    private static final String IMAGE_KEY = "jabberFilter";
    static {
        Images.getImageRegistry().put(IMAGE_KEY, 
          Images.createDescriptor(JabberFilterUI.class, "jabber.jpeg"));
    }
    
    public String getSmallIconId() {
        return IMAGE_KEY;
    }
    
    public Image getSmallImage() {
        return Images.get(IMAGE_KEY);
    }
    
    public ImageDescriptor getSmallIcon() {
        return Images.getImageDescriptor(IMAGE_KEY);
    }
}