package com.vordel.example.filter;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.vordel.circuit.Circuit;
import com.vordel.circuit.CircuitAbortException;
import com.vordel.circuit.Filter;
import com.vordel.circuit.Message;
import com.vordel.circuit.MessageProcessor;
import com.vordel.circuit.MessageProperties;
import com.vordel.dwe.ContentSource;
import com.vordel.es.EntityStore;
import com.vordel.es.EntityStoreException;
import com.vordel.mime.Body;
import com.vordel.mime.ContentType;
import com.vordel.mime.HeaderSet;
import com.vordel.mime.XMLBody;
import com.vordel.precipitate.SolutionPack;
import com.vordel.trace.Trace;

/**
 * This Processor acts as a simple Addition Web Service. It extracts two
 * parameters from a SOAP message and adds them together. The result is then
 * returned to the client. The incoming message is expected in the following
 * format:
 * 
 * <?xml version="1.0" encoding="utf-8"?>
 * <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 * <soap:Body> <Add xmlns="http://startvbdotnet.com/web/"> <a>1</a>
 * <b>1</b> </Add> </soap:Body> </soap:Envelope>
 * 
 * The SimpleFilter contains the local name of the two parameters (a and b), and
 * contains the namespace that these elements belong to
 * (http://startvbdotnet.com/web/).
 */
public class SimpleProcessor extends MessageProcessor {

	/**
	 * This method attaches the Filter to the Processor object. This is called
	 * at startup and on every refresh. This should contain server-side
	 * config/initialization. For example, if this filter is required to
	 * establish connections to any 3rd party products/servers, the connection
	 * setup should be done here.
	 * 
	 * @param ctx
	 *            Configuration context for the filter.
	 * @param entity
	 *            The Entity object
	 */
	public void filterAttached(SolutionPack ctx, com.vordel.es.Entity entity) throws EntityStoreException {
		// nothing to do here for initialisation
		super.filterAttached(ctx, entity);
	}

	/**
	 * The invoke method performs the filter processing.
	 * 
	 * @param c
	 *            The policy circuit
	 * @param message
	 *            The message
	 * @return true or false.
	 */
	public boolean invoke(Circuit c, Message message) throws CircuitAbortException {

		try {
			// Get the incoming request message as a DOM
			Trace.debug("DEBUG: Filter Processing Starts");

			Document doc = XMLBody.getDocument(message);
			//Trace.debug("DEBUG: Filter getDocument: " + doc.getDocumentElement().getNodeName());
			// Default result
			String result = "UNKNOWN";

			// Cast the filter member variable to a SimpleFilter so that
			// you may access the values stored in the SimpleFilter's
			// fields (for example, param1, param1Namespace, and so on).
			// SimpleFilter f = new SimpleFilter();
			SimpleFilter f = (SimpleFilter) getFilter();
			Trace.debug("DEBUG: Filter Parameters" + " : " + f.param1Namespace + " : " + f.param1 + " : "
					+ f.param2Namespace + " : " + f.param2);
			// Look into the DOM to get the two parameters.
			// Get the 1st parameter
			NodeList param1 = doc.getElementsByTagNameNS(f.param1Namespace, f.param1);
			if (param1 == null || param1.getLength() <= 0) {
				Trace.debug("DEBUG: Inside if ");
				throw new CircuitAbortException("Could not find " + f.param1 + "in message");
			}
			// Get the value passed in the 1st parameter
			//String a = param1.item(0).toString();
			String a = param1.item(0).getTextContent();
			Trace.debug("DEBUG: Filter Parameter a : " + a);

			// Get the 2nd parameter
			NodeList param2 = doc.getElementsByTagNameNS(f.param2Namespace, f.param2);
			if (param2 == null || param2.getLength() <= 0)
				throw new CircuitAbortException("Could not find " + f.param2 + "in message");

			// Get the value of the 2nd parameter
			//String b = param2.item(0).toString();
			String b = param2.item(0).getTextContent();
			Trace.debug("DEBUG: Filter Parameter b : " + b);
			// Calculate the result by adding the two parameter values
			result = Integer.toString(Integer.parseInt(a) + Integer.parseInt(b));
			Trace.debug("DEBUG: result : " + result);
			// Set the response by setting the content body
			// to be the response
			Trace.debug("DEBUG: Sets headers....");
			HeaderSet responseHeaders = new HeaderSet();
			responseHeaders.addHeader("Content-Type", "text/xml");
			Trace.debug("DEBUG: HTTP Body Content ....");
			StringBuffer response = new StringBuffer("RESPONSE_START");
			response.append(result);
			response.append("RESPONSE_END");
			responseHeaders.addHeader("Result", result);
			/*Trace.debug("DEBUG: HTTP Body ContentSource ....");
			 */
			Trace.debug("DEBUG: HTTP Body ....");
			ContentSource cs = null;
			Body convertedBody = Body.create(responseHeaders, new ContentType(null, "text/xml"), cs);
			Trace.debug("DEBUG: Puts HTTP Body into message ....");
			message.put(MessageProperties.CONTENT_BODY, convertedBody);
			//message.put(MessageProperties.HTTP_HEADERS, responseHeaders);
			
			//message.put(MessageProperties.HTTP_BODY, response);
			Trace.debug("DEBUG: Returns true");
			return true;
		} catch (IOException exp) {
			Trace.error("IOException in SimpleProcessor: " + exp.getMessage());
			return false;
		}
	}
}