package com.vordel.example.filter;

import com.vordel.circuit.DefaultFilter;
import com.vordel.circuit.ConfigContext;
//import com.vordel.circuit.FilterConfigureContext;
import com.vordel.circuit.PropDef;
import com.vordel.circuit.MessageProperties;
import com.vordel.es.EntityStoreException;
import com.vordel.precipitate.SolutionPack;

 /**
 SimpleFilter contains the local name of the two 
 parameters (a and b) and contains the namespace that 
 these elements belong to (http://startvbdotnet.com/web/)
  **/

public class SimpleFilter extends DefaultFilter {  
   
    // element name of the first parameter
    String param1;
    // namespace of the first element
    String param1Namespace;
    // element name of the second parameter
    String param2;
    // namespace of the second parameter
    String param2Namespace;

    /**
     * Set the message attributes used by this filter
     */
    protected final void setDefaultProperties() {
    	reqProps.add(new PropDef(MessageProperties.CONTENT_BODY, 
    	          com.vordel.mime.Body.class));
    }
    
    /**
     * This method is called to set the config fields for the filter
     * @param ctx The configuration context for this filter
     * @param entity The entity object
     */
    public void configure(SolutionPack ctx, com.vordel.es.Entity entity)
    	      throws EntityStoreException {
    	        super.configure(ctx, entity);
        
        // read the settings for the processor
        param1  = entity.getStringValue("param1");
        param1Namespace  = entity.getStringValue("param1Namespace");
        param2  = entity.getStringValue("param2");
        param2Namespace  = entity.getStringValue("param2Namespace");
    }
 
    /**
     * Returns the server runtime Processor class associated 
     * with this Filter class.
     */
    public Class getMessageProcessorClass() {
        return SimpleProcessor.class;
    }
    
    /**
     * Returns the GUI component for this Filter 
     */
    public Class getConfigPanelClass() throws ClassNotFoundException {
        // Avoid any compile or runtime dependencies on SWT and other UI 
        // libraries by lazily loading the class when required.
        return 
            Class.forName("com.vordel.example.filter.simple.SimpleFilterUI");
    }
}    