package com.vordel.example.filter.simple;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;

import com.vordel.client.manager.wizard.VordelPage;

public class SimpleFilterPage extends VordelPage 
{    
    /** 
     * Create the configuration page. Set the title and description 
     * here. The title and description are maintained in the 
     * resources.properties file for customization and 
     * internationalization purposes.
     */
    public SimpleFilterPage() {
        // Call the super constructor with a unique name for this 
        // page to bind it with its corresponding wizard.
        super("simplePage");
        setTitle(_("SIMPLE_PAGE"));
        setDescription(_("SIMPLE_PAGE_DESCRIPTION"));
        setPageComplete(false);
    }
    
    /**
     * Get the unique identifier for the help page for this filter. 
     * The ID-to-HTML page mapping is maintained in the following file:
     * <policy_studio_build>/plugins/
     * com.vordel.client.rcp.common.resources_version/contexts.xml. 
     */
    public String getHelpID() {
        return "simple.help";
    }

    /**
     * Any post-processing of the configuration values can happen 
     * here, before they are persisted to the Entity Store. If the 
     * configuration is not complete and valid, notify the user here  
     * with a dialog box and return false, otherwise return true.
     * 
     * @see com.vordel.client.manager.util.MsgBox
     */
    public boolean performFinish() {
        // Simple mutually independent values here, no checking required, 
        // so return true
        return true;
    }

    /**
     * Create the main control for the Filter configuration dialog. 
     * This will include the text fields for setting the particular 
     * Field Values in the Entity.
     */
    public void createControl(Composite parent) {
        // Create a Panel with two columns        
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;    
        Composite container = new Composite(parent, SWT.NULL);
        container.setLayout(layout);
        
        // Add controls to populate the appropriate Entity Fields
        // You use the localization keys for the field names and 
        // descriptions which will map to entries in the 
        // resources.properties file.        
        createLabel(container, "SF_NAME");
        createTextAttribute(container, "name", "SF_NAME_DESC");

        createLabel(container, "SF_PARAM1");
        createTextAttribute(container, "param1", "SF_PARAM1_DESC");
        
        createLabel(container, "SF_PARAM1NS");
        createTextAttribute(container, "param1Namespace", "SF_PARAM1NS_DESC");

        createLabel(container, "SF_PARAM2");
        createTextAttribute(container, "param2", "SF_PARAM2_DESC");
        
        createLabel(container, "SF_PARAM2NS");
        createTextAttribute(container, "param2Namespace", "SF_PARAM2NS_DESC");
        
        // Finish up the page definition
        setControl(container);
        setPageComplete(true);        
    }
}